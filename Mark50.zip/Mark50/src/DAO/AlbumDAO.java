package DAO;
import Moduli.Album;

import java.sql.Connection;
import java.sql.SQLException;

import Database.DBConnection;

public class AlbumDAO { 
	
	
	
	public AlbumDAO() {
		
		Album a = new Album();
		Connection con = null;
		DBConnection db = new DBConnection();
		
		db.getOracle(con);
	}


}

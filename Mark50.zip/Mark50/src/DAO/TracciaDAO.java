package DAO;

public class TracciaDAO {

}

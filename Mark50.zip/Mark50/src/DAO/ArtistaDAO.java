package DAO;

public class ArtistaDAO {

}

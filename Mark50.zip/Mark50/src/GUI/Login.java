package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel person = new JLabel("");
		person.setIcon(new ImageIcon(Login.class.getResource("/Immagini/LOGIN.png")));
		person.setHorizontalAlignment(SwingConstants.CENTER);
		person.setBounds(20, 6, 188, 228);
		contentPane.add(person);
		
		JLabel username = new JLabel("Username");
		username.setBounds(220, 68, 82, 16);
		contentPane.add(username);
		
		JTextField textUsername = new JTextField();
		textUsername.setBounds(220, 85, 144, 26);
		contentPane.add(textUsername);
		textUsername.setColumns(10);
		
		JLabel password = new JLabel("Password");
		password.setBounds(220, 123, 82, 16);
		contentPane.add(password);
		
		JTextField textPassword = new JTextField();
		textPassword.setBounds(220, 139, 144, 26);
		contentPane.add(textPassword);
		textPassword.setColumns(10);
		
		JButton continua = new JButton("Continua");
		continua.setIcon(null);
		continua.setBackground(Color.WHITE);
		continua.setBounds(327, 237, 117, 29);
		contentPane.add(continua);
		continua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection(  "jdbc:oracle:thin:@localhost:1521:orclcdb","system","oracle");  
					System.out.println("CONNECTION STATUS = OK"); 
					String sql = "select * from login where username=? and password=?";
					PreparedStatement pst = con.prepareStatement(sql);
					pst.setString(1, textUsername.getText());
					pst.setString(2, textPassword.getText());
					ResultSet rs = pst.executeQuery();
					if(rs.next()) {
						JOptionPane.showMessageDialog(null, "Username e Password Corretti");
						Menu m =new Menu();
						m.setVisible(true);
						setVisible(false);
						
					}
					else {
						JOptionPane.showMessageDialog(null, "Username e Password Errate");
						textUsername.setText("");
						textPassword.setText("");
					}
					con.close();
					
				
				}
				catch (SQLException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					System.out.println("CONNECTION STATUT = FAILURE");
					String s1="OPERATION FAILED";
					JOptionPane.showMessageDialog(continua, s1);
					System.out.println(e1);
				}
				
			}
		});
		
		JButton indietro = new JButton("Indietro");
		indietro.addActionListener((ActionListener) new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
				new Home().setVisible(true);
			}
		});
		indietro.setBounds(208, 237, 117, 29);
		contentPane.add(indietro);
		
		
		
		JLabel sfondo = new JLabel("");
		sfondo.setIcon(new ImageIcon(getClass().getResource("/Immagini/SfondoBigSur.png")));
		sfondo.setBounds(0, -16, 450, 300);
		contentPane.add(sfondo,"cell 0 0 40 18,align center center,grow 0 0");
	}
}

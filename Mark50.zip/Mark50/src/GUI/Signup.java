package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Signup extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup frame = new Signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Signup() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel username = new JLabel("Username");
		username.setBounds(186, 88, 97, 16);
		contentPane.add(username);
		
		JTextField textUsername = new JTextField();
		textUsername.setBounds(130, 116, 176, 26);
		contentPane.add(textUsername);
		textUsername.setColumns(10);
		
		JLabel password = new JLabel("Password");
		password.setBounds(187, 154, 61, 16);
		contentPane.add(password);
		
		JTextField textPassword = new JTextField();
		textPassword.setBounds(130, 182, 176, 26);
		contentPane.add(textPassword);
		textPassword.setColumns(10);
		
		JLabel sfondo = new JLabel("");
		sfondo.setIcon(new ImageIcon(Signup.class.getResource("/Immagini/register.png")));
		sfondo.setHorizontalAlignment(SwingConstants.CENTER);
		sfondo.setBounds(117, 6, 199, 98);
		contentPane.add(sfondo);
		
		JButton sign_up = new JButton("Sign up");
		sign_up.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{Connection con=DriverManager.getConnection(  "jdbc:oracle:thin:@localhost:1521:orclcdb","system","oracle");  
				System.out.println("CONNECTION STATUS = OK"); 
				java.sql.Statement stm=con.createStatement();
				int i=stm.executeUpdate("insert into login values(pk_login.nextval,'"+ textUsername.getText() +"','"+ textPassword.getText() +"')" );
				System.out.println(i);
				String s="Sign Up Successful, verrete reinstradati alla pagina Home";
				JOptionPane.showMessageDialog(sign_up, s);
				Home h = new Home();
				h.setVisible(true);
				setVisible(false);
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.out.println("CONNECTION STATUT = FAILURE");
					String s1="Sign Up Failed";
					JOptionPane.showMessageDialog(sign_up, s1);
					System.out.println(e1);
				}
				
			}
			
		});
		sign_up.setBounds(160, 220, 117, 29);
		contentPane.add(sign_up);
		
		JButton indietro = new JButton("indietro");
		indietro.addActionListener((ActionListener) new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
				new Home().setVisible(true);
			}
		});
		indietro.setBounds(0, 237, 117, 29);
		contentPane.add(indietro);
		
		JLabel lblNewLabelx = new JLabel("");
		lblNewLabelx.setIcon(new ImageIcon(getClass().getResource("/Immagini/SfondoBigSur.png")));
		lblNewLabelx.setBounds(0, -16, 450, 300);
		contentPane.add(lblNewLabelx,"cell 0 0 40 18,align center center,grow 0 0");
		
		
	}
}

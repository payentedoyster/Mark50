package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu file = new JMenu("File");
		menuBar.add(file);
		
		JMenuItem apriFile = new JMenuItem("Apri File");
		file.add(apriFile);
		apriFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				apriFile();
			}

		});
		
		JMenu nuovo = new JMenu("Nuovo");
		menuBar.add(nuovo);
		
		JMenuItem nuovoArtista = new JMenuItem("Nuovo Artista");
		nuovo.add(nuovoArtista);
		nuovoArtista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				CreaArtista ca = new CreaArtista();
				ca.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenuItem nuovoAlbum = new JMenuItem("Nuovo Album");
		nuovo.add(nuovoAlbum);
		nuovoAlbum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				CreaAlbum cal = new CreaAlbum();
				cal.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenuItem nuovoTraccia = new JMenuItem("Nuovo Traccia");
		nuovo.add(nuovoTraccia);
		nuovoTraccia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				CreaTraccia ct = new CreaTraccia();
				ct.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenuItem nuovoUtente = new JMenuItem("Nuovo Utente");
		nuovo.add(nuovoUtente);
		nuovoUtente.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				CreaUtente cu = new CreaUtente();
				cu.setVisible(true);
				setVisible(false);



			}

		});
		
		JMenuItem nuovoScript = new JMenuItem("Nuovo Script");
		nuovo.add(nuovoScript);
		nuovoScript.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				try {
					Script frame = new Script();
					frame.setVisible(true);
					setVisible(false);

				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}




			}});
		
		JMenu modifica = new JMenu("Modifica");
		menuBar.add(modifica);
		
		JMenuItem modificaUtente = new JMenuItem("Modifica Utente");
		modifica.add(modificaUtente);
		modificaUtente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				ModificaUtente mu = new ModificaUtente();
				mu.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenuItem modificaTraccia = new JMenuItem("Modifica Traccia");
		modifica.add(modificaTraccia);
		modificaTraccia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				ModificaTraccia mt = new ModificaTraccia();
				mt.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenuItem modificaAlbum = new JMenuItem("Modifica Album");
		modifica.add(modificaAlbum);
		modificaAlbum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				ModificaAlbum ma = new ModificaAlbum();
				ma.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenuItem modificaArtista = new JMenuItem("Modifica Artista");
		modifica.add(modificaArtista);
		modificaArtista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				ModificaArtista mart = new ModificaArtista();
				mart.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenu crea = new JMenu("Crea");
		menuBar.add(crea);
		
		JMenuItem creaDB = new JMenuItem("Crea Database");
		crea.add(creaDB);
		creaDB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				CreaDb frame=new CreaDb();
				frame.setVisible(true);
				setVisible(false);



			}

		});
		
		JMenuItem creaTabella = new JMenuItem("Crea Tabella");
		crea.add(creaTabella);
		creaTabella.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				CreaTabella frame=new CreaTabella();
				frame.setVisible(true);
				setVisible(false);



			}

		});
		
		JMenuItem creaTrigger = new JMenuItem("Crea Trigger");
		crea.add(creaTrigger);
		creaTrigger.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				
				CreaTrigger cu = new CreaTrigger();
				cu.setVisible(true);
				setVisible(false);

			}
			
		});
		
		JMenu account = new JMenu("Account");
		menuBar.add(account);
		
		JMenuItem my = new JMenuItem("My");
		account.add(my);
		my.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				Account frame=new Account();
				frame.setVisible(true);
				setVisible(false);



			}

		});
		
		
		
		
		
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBounds(0, 0, 450, 272);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel logo = new JLabel("");
		logo.setBounds(30, 55, 134, 132);
		panel.add(logo);
		logo.setIcon(new ImageIcon(Test.class.getResource("/Immagini/Provalogo.png")));
		logo.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel projectName = new JLabel("PROJECT_NAME");
		projectName.setFont(new Font(".AppleSystemUIFont", Font.PLAIN, 22));
		projectName.setHorizontalAlignment(SwingConstants.CENTER);
		projectName.setBounds(176, 108, 217, 35);
		panel.add(projectName);
		
		JLabel sfondo = new JLabel("");
		sfondo.setBounds(0, -12, 450, 300);
		panel.add(sfondo);
		sfondo.setIcon(new ImageIcon(getClass().getResource("/Immagini/SfondoBigSur.png")));

		
	}
	
	private void apriFile() {
		JFileChooser fileChooser = new JFileChooser();
		int r = fileChooser.showOpenDialog(this);

		if (r == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			// .....usa file
		}
	}

}

package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Panel;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public Home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel welcome = new JLabel("Welcome");
		welcome.setFont(new Font(".AppleSystemUIFont", Font.PLAIN, 25));
		welcome.setBounds(170, 61, 117, 54);
		contentPane.add(welcome);
		
		JButton login = new JButton("Login");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login gx = new Login();
				gx.setVisible(true);
				setVisible(false);
				
			}
		});
		login.setBounds(236, 128, 117, 29);
		contentPane.add(login);
		
		JButton sign_up = new JButton("Sign up");
		sign_up.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Signup su = new Signup();
				su.setVisible(true);
				setVisible(false);
				
			}
		});
		sign_up.setBounds(107, 128, 117, 29);
		contentPane.add(sign_up);
		

		
		JLabel sfondo = new JLabel("");
		sfondo.setIcon(new ImageIcon(getClass().getResource("/Immagini/SfondoBigSur.png")));
		sfondo.setBounds(0, -16, 450, 300);
		contentPane.add(sfondo,"cell 0 0 40 18,align center center,grow 0 0");

		Panel panel = new Panel();
		panel.setBounds(0, 0, 450, 272);
		contentPane.add(panel);
	}
	
	public static void main(String[] args) {
		Home frame = new Home();
		frame.setVisible(true);
	}

}

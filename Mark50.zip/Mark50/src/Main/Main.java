package Main;

import java.awt.EventQueue;
import GUI.Menu;
import GUI.Home;

public class Main {

	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			@SuppressWarnings("unused")
			public void run() {
				try {
					Home h = new Home(); //Viene inizializzato il controller. Il costruttore e il metood initialize saranno inutili: il controllo verr� passato alla prossima schermata.
					h.setVisible(true);
					/*Demo d = new Demo();
					d.setVisible(true);*/
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}

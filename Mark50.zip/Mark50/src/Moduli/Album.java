package Moduli;

public class Album {
	
		private int codice;
	    private String nome;
	    
	    Anno n = new Anno();

	    public int getCodice(){
	        return codice;
	    }

	    public String getNome(){
	        return nome;
	    }

}

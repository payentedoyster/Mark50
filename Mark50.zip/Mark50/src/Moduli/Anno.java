package Moduli;

public class Anno {
	
    private int giorno;
    private int mese;
    private int anno;

    public int getGiorno(){

        return giorno;

    }

    public int getMese(){

        return mese;

    }

    public int getAnno(){

        return anno;

    }

}

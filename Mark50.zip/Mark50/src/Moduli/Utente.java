package Moduli;

public class Utente {
	
		private String identify;
	    private String email;
	    private int eta;
	    private String citta;
	    private String via;
	    private String n_civico;
	    private String nazionalita;

	    public String getIdentify(){
	        return identify;
	    }

	    public String getEmail(){
	        return email;
	    }

	    public String getCitta(){
	        return citta;
	    }

	    public String getN_civico(){
	        return n_civico;
	    }

	    public String getNazionalita(){
	        return nazionalita;
	    }

	    public int getEta(){
	        return eta;
	    }

}

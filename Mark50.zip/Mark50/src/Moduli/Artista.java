package Moduli;

public class Artista {
	
	   private String nome;
	    private int eta;
	    char sesso;

	    public String getNome(){
	        return nome;
	    }

	    public int getEta(){
	        return eta;
	    }

	    public char getSesso(){
	        return sesso;
	    }

}

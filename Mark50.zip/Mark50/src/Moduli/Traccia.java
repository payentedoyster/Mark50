package Moduli;

public class Traccia {
	
    private int codice;
    private String nome;
    Anno a = new Anno();
    private int n_ascolti;
    private String fascia_oraria;
    private String tipo;
    private String genere;
    private String cod_artista;
    private int cod_album;

    public String getNome(){
        return nome;
    }
    public String getFascia_oraria(){
        return fascia_oraria;
    }

    public String getTipo(){
        return tipo;
    }

    public String getGenere(){
        return genere;
    }

    public String getCod_artista(){
        return cod_artista;
    }

    public int getCodice(){
        return codice;
    }

    public int getN_ascolti(){
        return n_ascolti;
    }

    public int getCod_album(){
        return cod_album;
    }

}

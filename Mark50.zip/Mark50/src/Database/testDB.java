package Database;

import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class testDB {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Connection con = null;
		DBConnection db = new DBConnection();
		db.getOracle(con);


	}
		
}

package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {


	private Connection con;
	
	public void getOracle(Connection con) {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orclcdb","system","oracle");
			System.out.println("CONNECTION STATUS OK");
			
			
		}
		catch(ClassNotFoundException e) {
			
			System.out.println("DB DRIVER NOT FOUND");
			System.out.println(e);
			
		}
		catch(SQLException e) {
			
			System.out.println("CONNECTION STATUS FAILURE");
			System.out.println(e);
			
		}
		
				
		
	}

}

module Mark50 {
	requires java.sql;
	requires java.desktop;
}